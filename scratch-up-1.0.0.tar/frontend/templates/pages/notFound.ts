const title = `Not Found`;
const body = `<h1>Couldn't find ! what you are looking for \\(0_0)/</h1>`;

export { title, body };
