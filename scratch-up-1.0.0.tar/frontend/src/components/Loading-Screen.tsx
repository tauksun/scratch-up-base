import "../css/Loading-Screen.css";

const loadingScreen = () => {
  const loadingJSX = <div id="loadingScreen">Loading ...</div>;
  return loadingJSX;
};

export default loadingScreen;
