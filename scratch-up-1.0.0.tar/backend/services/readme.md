### Checkout list of knex queries here :
[knex-queries](https://knexjs.org/guide/query-builder.html)