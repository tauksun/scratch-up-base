const helloLua = `
function()
    return "Hello from loaded lua function"
end
`

export default helloLua;