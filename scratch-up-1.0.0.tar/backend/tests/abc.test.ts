// import { abc } from "../api/abc";

// test("Tesing jest configuration", () => {
//   const result = abc("khana");
//   expect(result).toBe("you have ordered : khana");
// });
