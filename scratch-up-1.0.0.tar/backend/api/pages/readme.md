# Pages

    Send html pages for http errors 
    or custom logical errors

## Add a new page

    - Define a request handler in /pages/index.ts
    - For new custom page 
        - Define html body under /templates/pages
        - Edit /templates/pages/index.ts accordingly to get typescript benefit
