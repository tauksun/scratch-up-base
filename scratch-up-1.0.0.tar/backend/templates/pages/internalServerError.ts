const title = `Server Error`;
const body = `<h1>Internal Server Error (0_0)</h1>`;

export { title, body };
