const title = `Error`;
const body = `<h1>Bad Request</h1>`;

export { title, body };
