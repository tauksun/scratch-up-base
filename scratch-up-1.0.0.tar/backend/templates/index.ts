import getBaseTemplate from "./base-template";
import getHtmlPage, { IPage } from "./pages";

export { getBaseTemplate, getHtmlPage, IPage };
