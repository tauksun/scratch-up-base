import expressServerApp from "./app";
expressServerApp();
